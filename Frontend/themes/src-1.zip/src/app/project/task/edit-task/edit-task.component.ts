import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-edit-task',
  templateUrl: './edit-task.component.html',
  styleUrls: ['./edit-task.component.css']
})
export class EditTaskComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  editTaskFrom =new FormGroup({
    taskId:new FormControl(""),
    taskTitle:new FormControl(""),
    taskDetails:new FormControl(""),
    taskStatus:new FormControl(""),
    taskAssignBy:new FormControl(""),
    taskPriority:new FormControl(""),
    startDate:new FormControl(""),
    endDate:new FormControl("")
  })
  
  onsubmit(){
    console.log(this.editTaskFrom.value);
    
  }
}
